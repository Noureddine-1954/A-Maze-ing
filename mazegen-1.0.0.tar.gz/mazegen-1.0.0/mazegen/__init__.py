from mazegen.cell_class import Cell
from mazegen.maze_gen import MazeGenerator

__all__ = [
    "Cell",
    "MazeGenerator",
    "maze_solver",
]

__version__ = "1.0"
__authors__ = ["nel-mout", "ylhamidi"]
