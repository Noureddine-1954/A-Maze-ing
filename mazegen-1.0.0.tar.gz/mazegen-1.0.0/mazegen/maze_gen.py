from typing import Optional, Tuple
from mazegen import Cell
from time import time
from collections import deque


class MazeGenerator:
    """
    Generates a 2D maze grid using a depth-first search (DFS) algorithm.

    The maze consists of `Cell` objects arranged in a rectangular grid.
    The generator supports both perfect mazes (no cycles, exactly one path
    between any two points) and imperfect mazes (with loops). It can also
    optionally embed a predefined "42 pattern" inside the maze when the
    dimensions allow it.

    The generation process works as follows:
        1. Initialize a grid of fully closed cells.
        2. Mark entrance and exit cells.
        3. Optionally carve a fixed "42 pattern" in the center.
        4. Use a randomized DFS (backtracking) algorithm to carve passages.
        5. If the maze is not perfect, randomly open additional walls to
           introduce cycles.

    Attributes:
        height (int): Number of rows in the maze.
        width (int): Number of columns in the maze.
        entrance (Tuple[int, int]): Coordinates (row, col) of the entry cell.
        departure (Tuple[int, int]): Coordinates (row, col) of the exit cell.
        seed (Optional[int]): Seed for the random number generator to allow
            reproducible maze generation.
        perfect (bool): If True, generates a perfect maze (no loops).
            If False, introduces random cycles.

    Methods:
        generate_maze() -> list[list[Cell]]:
            Generates and returns the maze as a 2D list of `Cell` objects.
    """
    def __init__(self,
                 height: int,
                 width: int,
                 entrance: Tuple[int, int],
                 departure: Tuple[int, int],
                 seed: Optional[int],
                 perfect: bool):
        self.height = height
        self.width = width
        self.entrance = entrance
        self.departure = departure
        self.seed = seed
        self.perfect = perfect
        self.benchmark = {
            "generation": 0.0,
            "solution": 0.0
        }

    def generate_maze(self) -> list[list[Cell]]:
        start_time = time()
        width = self.width
        height = self.height

        maze = [[Cell(0) for _ in range(width)] for _ in range(height)]

        ent_x, ent_y = self.entrance
        ext_x, ext_y = self.departure
        maze[ent_x][ent_y].is_start = True
        maze[ext_x][ext_y].is_end = True

        def force_ftwo() -> None:
            four = [
                [0, 1, 0, 1, 0],
                [0, 1, 0, 1, 0],
                [0, 1, 1, 1, 0],
                [0, 0, 0, 1, 0],
                [0, 0, 0, 1, 0],
            ]
            two = [
                [0, 1, 1, 1, 0],
                [0, 0, 0, 1, 0],
                [0, 1, 1, 1, 0],
                [0, 1, 0, 0, 0],
                [0, 1, 1, 1, 0],
            ]

            rw_off = height // 2 - 2
            cl_off = width // 2 - 5

            for r, row in enumerate(four):
                for c, val in enumerate(row):
                    if val:
                        if r == 0 and rw_off - 1 >= 0:
                            maze[rw_off - 1][cl_off + c].south = False
                        maze[rw_off + r][cl_off + c - 1].east = False
                        maze[rw_off + r][cl_off + c] = Cell(0)
                        maze[rw_off + r][cl_off + c].is_ftwo = True

            for r, row in enumerate(two):
                for c, val in enumerate(row):
                    if val:
                        if r == 0 and rw_off - 1 >= 0:
                            maze[rw_off - 1][cl_off + 5 + c].south = False
                        maze[rw_off + r][cl_off + 5 + c - 1].east = False
                        maze[rw_off + r][cl_off + 5 + c] = Cell(0)
                        maze[rw_off + r][cl_off + 5 + c].is_ftwo = True

        if not (width < 10 or height < 7):
            force_ftwo()

        def carve() -> None:
            from random import shuffle, seed as set_seed, random

            if self.seed is not None:
                set_seed(self.seed)

            # Directions:
            # (row_delta, col_delta, wall_on_current, wall_on_neighbor)
            dirs = [
                (-1,  0, 'north', 'south'),
                (1,  0, 'south', 'north'),
                (0,  1, 'east',  'west'),
                (0, -1, 'west',  'east'),
            ]

            visited = [[maze[r][c].is_ftwo
                        for c in range(width)] for r in range(height)]

            stack = [(ent_x, ent_y)]
            visited[ent_x][ent_y] = True

            while stack:
                r, c = stack[-1]

                neighbors = [
                    (r + dr, c + dc, cur_wall, nbr_wall)
                    for dr, dc, cur_wall, nbr_wall in dirs
                    if 0 <= r + dr < height
                    and 0 <= c + dc < width
                    and not visited[r + dr][c + dc]
                ]

                if not neighbors:
                    stack.pop()
                    continue

                shuffle(neighbors)
                nr, nc, cur_wall, nbr_wall = neighbors[0]

                # Open the wall between current cell and chosen neighbor
                setattr(maze[r][c],   cur_wall, True)
                setattr(maze[nr][nc], nbr_wall, True)

                visited[nr][nc] = True
                stack.append((nr, nc))

            # If not perfect, punch extra passages to create loops
            if not self.perfect:
                for r in range(height):
                    for c in range(width):
                        if maze[r][c].is_ftwo:
                            continue
                        if r + 1 < height and not maze[r + 1][c].is_ftwo:
                            if random() < 0.1:
                                maze[r][c].south = True
                                maze[r + 1][c].north = True
                        if c + 1 < width and not maze[r][c + 1].is_ftwo:
                            if random() < 0.1:
                                maze[r][c].east = True
                                maze[r][c + 1].west = True

        carve()
        self.benchmark["generation"] = time() - start_time

        return maze

    def maze_solver(self,
                    maze: list[list[Cell]],
                    start: Tuple[int, int],
                    departure: Tuple[int, int]) -> list[Tuple[int, int]]:
        """
        Solves a maze using the Breadth-First Search (BFS) algorithm.

        This function finds the shortest path from the start position to the
        departure position in a maze represented as a 2D grid of `Cell`.
        It traverses only through open walls and avoids revisiting cells.

        The algorithm works as follows:
            1. Start from the given starting cell.
            2. Explore all reachable neighboring cells level by level (BFS).
            3. Track each visited cell and its predecessor.
            4. Stop when the departure cell is reached.
            5. Reconstruct the path by backtracking from the departure to the
            start.
            6. Mark the path in the maze by setting `is_path = True`.

        Args:
            maze (list[list[Cell]]): A 2D grid representing the maze.
            start (Tuple[int, int]): Coordinates (row, col) of the start.
            departure (Tuple[int, int]): Coordinates (row, col) of the target.

        Returns:
            list[Tuple[int, int]]: The shortest path from start to departure as
            list of coordinates. If no path exists, returns a path containing
            only the departure if it was never reached.

        Notes:
            - Movement is allowed only through open walls
            (where the corresponding direction attribute is True).
            - The function modifies the input maze by marking the solution.
        """
        start_time = time()
        directions = {
            "east":  (0,  1),
            "west":  (0, -1),
            "south": (1,  0),
            "north": (-1, 0),
        }

        visited: dict[Tuple[int, int], Optional[Tuple[int, int]]] = {start:
                                                                     None}
        queue = deque([start])

        while queue:
            r, c = queue.popleft()

            if (r, c) == departure:
                break

            for wall, (dr, dc) in directions.items():
                if not getattr(maze[r][c], wall):
                    continue
                nr, nc = r + dr, c + dc
                if (nr, nc) in visited:
                    continue
                if not (0 <= nr < len(maze) and 0 <= nc < len(maze[0])):
                    continue
                visited[(nr, nc)] = (r, c)
                queue.append((nr, nc))

        path = []
        current: Optional[Tuple[int, int]] = departure
        while current is not None:
            path.append(current)
            current = visited.get(current)
        path.reverse()

        dir_map = {
            (-1, 0): "⮝",
            (1, 0): "⮟",
            (0, 1): "⮞",
            (0, -1): "⮜"
        }

        # iterate with index to access "next"
        for i in range(len(path)):
            r, c = path[i]
            maze[r][c].is_path = True

            if i < len(path) - 1:
                nr, nc = path[i + 1]
                dr, dc = nr - r, nc - c
                maze[r][c].next_block = dir_map[(dr, dc)]
            else:
                # last cell (departure)
                maze[r][c].next_block = ""

        self.benchmark["solution"] = time() - start_time

        return path
